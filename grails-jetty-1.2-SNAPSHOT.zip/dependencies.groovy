app {
    name = "jetty"
    version = "1.2-SNAPSHOT"
    grailsVersion = "1.2 > *"
    servletVersion = "2.5"
}

plugin {
    author = "Graeme Rocher"
    authorEmail = "graeme.rocher@springsource.com"
    title = "Jetty Plugin"
    description = '''\\
Makes Jetty the development time container for Grails
'''
    documentation = "http://grails.org/plugin/jetty"

    excludes = [ "grails-app/views/error.gsp" ]

    // The Gradle plugin class.
    buildPluginClass = "org.grails.jetty.JettyBuildPlugin"
}

grails.project.class.dir = "target/classes"
grails.project.test.class.dir = "target/test-classes"
grails.project.test.reports.dir	= "target/test-reports"

grails.project.dependency.resolution = {
    inherits "global" // inherit Grails' default dependencies
    log "warn" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'

    repositories {
        grailsHome()
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        // specify dependencies here under either 'build', 'compile', 'runtime', 'test' or 'provided' scopes eg.
        // runtime 'com.mysql:mysql-connector-java:5.1.5'
        compile 'org.mortbay.jetty:jetty:6.1.21', 'org.mortbay.jetty:jetty-plus:6.1.21'

        build   'org.mortbay.jetty:jetty:6.1.21',
                'org.mortbay.jetty:jetty-plus:6.1.21',
                'org.mortbay.jetty:jetty-util:6.1.21',
                'org.mortbay.jetty:jetty-naming:6.1.21'

        build('org.mortbay.jetty:jsp-2.0:6.1.21') {
            excludes 'commons-el', 'ant', 'slf4j-api', 'slf4j-simple', 'jcl104-over-slf4j', 'xercesImpl', 'xmlParserAPIs'
        }
    }

}

