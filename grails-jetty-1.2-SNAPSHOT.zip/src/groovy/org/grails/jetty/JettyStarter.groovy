package org.grails.jetty

import org.mortbay.jetty.webapp.WebAppContext
import org.mortbay.jetty.nio.SelectChannelConnector
import org.mortbay.jetty.Server
import org.mortbay.jetty.Connector
import org.mortbay.jetty.security.SslSocketConnector

class JettyStarter {
    def context
    def envXmlUrl
    def server
    def webDefaults

    JettyStarter(String warPath, String contextPath) {
        this.context = new WebAppContext(war:warPath, contextPath:contextPath)
    }

    JettyStarter(String baseDir, String webXml, String contextPath, ClassLoader classLoader, File webDefaults) {
        println "JettyStarter (basedir = ${baseDir}, context = ${contextPath})"
        this.webDefaults = webDefaults
        this.context = createStandardContext(baseDir, webXml, contextPath, classLoader)
    }

    /**
     * Starts the given Grails server
     */
    void startServer(String host, int httpPort, int httpsPort = 0) {
        if (httpsPort) {
            server = configureHttpsServer(context, httpPort, httpsPort, host)
        }
        else {
            server = configureHttpServer(context, httpPort, host)
        }

        server.start()
    }

    void stopServer() {
        server?.stop()
    }

    /**
     * Creates a standard WebAppContext from the given arguments
     */
    protected WebAppContext createStandardContext(String webappRoot, String webXml, String contextPath, ClassLoader classLoader) {
        println ">> Webapp context: ${webappRoot}  ${webXml}"
        def webContext = new WebAppContext(webappRoot, contextPath)
        def configurations = [org.mortbay.jetty.webapp.WebInfConfiguration,
                org.mortbay.jetty.plus.webapp.Configuration,
                org.mortbay.jetty.webapp.JettyWebXmlConfiguration,
                org.mortbay.jetty.webapp.TagLibConfiguration]*.newInstance()
        def jndiConfig = new org.mortbay.jetty.plus.webapp.EnvConfiguration()
        if (envXmlUrl) {
            jndiConfig.setJettyEnvXml(envXmlUrl)
        }

        configurations.add(1, jndiConfig)
        webContext.configurations = configurations
        webContext.setDefaultsDescriptor(webDefaults.path)
        webContext.setClassLoader(classLoader)
        webContext.setDescriptor(webXml)
        return webContext
    }



    /**
     * Configures a new Jetty Server instance for the given WebAppContext
     */
    protected configureHttpServer(WebAppContext context, int serverPort = DEFAULT_PORT, String serverHost = DEFAULT_HOST) {
        def jetty = new Server()
        def connectors = [ new SelectChannelConnector() ]
        connectors[0].port = serverPort
        if (serverHost) {
            connectors[0].host = serverHost
        }
        jetty.connectors = connectors
        jetty.handler = context
        return jetty
    }


    /**
     * Configures a secure HTTPS server
     */
    protected configureHttpsServer(WebAppContext context, int httpPort = DEFAULT_PORT, int httpsPort = DEFAULT_SECURE_PORT, String serverHost = DEFAULT_HOST ) {
        def jetty = configureHttpServer(context, httpPort, serverHost)
        if (!(keystoreFile.exists())) {
            createSSLCertificate()
        }
        def secureListener = new SslSocketConnector()
        secureListener.port = httpsPort
        if (serverHost) {
            secureListener.host = serverHost
        }
        secureListener.maxIdleTime = 50000
        secureListener.password = keyPassword
        secureListener.keyPassword = keyPassword
        secureListener.keystore = keystore
        secureListener.needClientAuth = false
        secureListener.wantClientAuth = true

        def connectors = jetty.connectors.toList()
        connectors.add(secureListener)
        jetty.connectors = connectors.toArray(new Connector[0])
        return jetty
    }


    /**
     * Creates the necessary SSL certificate for running in HTTPS mode
     */
    protected createSSLCertificate() {
        println 'Creating SSL Certificate...'
        if (!keystoreFile.parentFile.exists() &&
                !keystoreFile.parentFile.mkdir()) {
            def msg = "Unable to create keystore folder: " + keystoreFile.parentFile.canonicalPath
            throw new RuntimeException(msg)
        }
        String[] keytoolArgs = ["-genkey", "-alias", "localhost", "-dname",
                "CN=localhost,OU=Test,O=Test,C=US", "-keyalg", "RSA",
                "-validity", "365", "-storepass", "key", "-keystore",
                "${keystore}", "-storepass", "${keyPassword}",
                "-keypass", "${keyPassword}"]
        KeyTool.main(keytoolArgs)
        println 'Created SSL Certificate.'
    }
}
