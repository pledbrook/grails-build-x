/* Copyright 2004-2005 Graeme Rocher
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.grails.jetty

import grails.web.container.EmbeddableServer
import grails.util.BuildSettingsHolder
import grails.util.BuildSettings
import sun.security.tools.KeyTool
import org.springframework.core.io.ClassPathResource
import org.springframework.core.io.FileSystemResource
import org.springframework.util.FileCopyUtils
import org.codehaus.groovy.grails.commons.ConfigurationHolder

/**
 * An implementation of the EmbeddableServer interface for Jetty.
 *
 * @see EmbeddableServer
 *
 * @author Graeme Rocher
 * @since 1.2
 *
 * Created: Jan 7, 2009
 */
public class JettyServer implements EmbeddableServer{

    BuildSettings buildSettings
    def eventListener
    def jettyStarter

    protected String keystore
    protected File keystoreFile
    protected String keyPassword


    /**
     * Creates a new JettyServer for the given war and context path
     */
    public JettyServer(String warPath, String contextPath) {
        super()
        initialize()

        jettyStarter = new JettyStarter(warPath, contextPath)
    }

    /**
     * Constructs a Jetty server instance for the given arguments. Used for inline, non-war deployment
     *
     * @basedir The web application root
     * @webXml The web.xml definition
     * @contextPath The context path to deploy to
     * @classLoader The class loader to use
     */
    public JettyServer(String basedir, String webXml, String contextPath, ClassLoader classLoader) {
        super()
        initialize()

        // Jetty requires a "defaults descriptor" on the filesystem. So,
        // we copy it from Grails to the project work directory (if it's
        // not already there).
        def webDefaults = new File("${buildSettings.projectWorkDir}/webdefault.xml")
        if (!webDefaults.exists()) {
            FileCopyUtils.copy(
                    grailsResource("conf/webdefault.xml").inputStream,
                    new FileOutputStream(webDefaults.path))
        }

        jettyStarter = classLoader.loadClass("org.grails.jetty.JettyStarter").newInstance(
                basedir, webXml, contextPath, classLoader, webDefaults)
    }

    /**
     * Initializes the JettyServer class
     */
    protected initialize() {
        this.buildSettings = BuildSettingsHolder.settings

        def config = ConfigurationHolder.config ?: buildSettings.config
        if (config.grails.development.jetty.env) {
            def res = new FileSystemResource(config?.grails.development.jetty.env.toString())
            if (res) {
                jettyStarter.envXmlUrl = res.URL
            }
        }

        keystore = "${buildSettings.grailsWorkDir}/ssl/keystore"
        keystoreFile = new File("${keystore}")
        keyPassword = "123456"

        System.setProperty('org.mortbay.xml.XmlParser.NotValidating', 'true')
    }

    /**
     * @see EmbeddableServer#start()
     */
    void start() { start DEFAULT_PORT }

    /**
     * @see EmbeddableServer#start(int)
     */
    void start(int port) {
        start DEFAULT_HOST, port
    }

    /**
     * @see EmbeddableServer#start(String, int)
     */
    public void start (String host, int port) {
        print ">> Starting server..."
        eventListener?.event("ConfigureJetty", [this])
        jettyStarter.startServer host, port
        println "OK"
    }

    /**
     * @see EmbeddableServer#startSecure()
     */
    void startSecure() { startSecure DEFAULT_SECURE_PORT }

    /**
     * @see EmbeddableServer#startSecure(int)
     */
    void startSecure(int httpsPort) {
        startSecure DEFAULT_HOST, DEFAULT_PORT, httpsPort
    }

    public void startSecure (String host, int httpPort, int httpsPort) {
        eventListener?.event("ConfigureJetty", [this])
        jettyStarter.startServer host, httpPort, httpsPort
    }


    /**
     * @see EmbeddableServer#stop()
     */
    void stop() {
        jettyStarter.stopServer()
    }

    /**
     * @see EmbeddableServer#restart()
     */
    void restart() {
        stop()
        start()
    }

    private grailsResource(String path) {
        if (buildSettings.grailsHome) {
            return new FileSystemResource("${buildSettings.grailsHome}/$path")
        }
        else {
            return new ClassPathResource(path)
        }
    }
}
