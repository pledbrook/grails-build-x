package org.grails.jetty

import grails.util.GrailsNameUtils

import org.codehaus.groovy.grails.cli.support.GrailsRootLoader
import org.codehaus.groovy.grails.cli.support.GrailsBuildHelper
import org.gradle.api.Plugin
import org.gradle.api.Project

class JettyBuildPlugin implements Plugin<Project> {
    /**
     * These Grails commands require the project's runtime dependencies
     * in the Grails root loader because they are not using the runtime
     * classpath (as they are supposed to).
     */
    static final RUNTIME_CLASSPATH_COMMANDS = [ "RunApp", "TestApp" ] as Set

    void use(Project project) {
        def pluginProject = project.grailsPlugins["jetty"]
        project.dependencies {
            servletContainer pluginProject.sourceSets.main.runtimeClasspath
            runtime pluginProject.sourceSets.main.runtimeClasspath
        }
    }
}
